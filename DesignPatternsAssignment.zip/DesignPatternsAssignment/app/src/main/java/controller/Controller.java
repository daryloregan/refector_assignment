package controller;

import android.content.Context;

import java.util.ArrayList;

import model.Database;
import model.Item;
import model.Order;

public class Controller {
    Database database;

    public Controller(Context context){
        database = new Database(context);
    }

    public void addUser(String username, String password, String address, String payment, String type) {
        database.addUser(username, password, address, payment, type);
    }

    public String checkLogin(String username, String password) {
        return database.checkLogin(username, password);
    }

    public void addItem(Item item) {
        database.addItem(item);
    }

    public ArrayList<Item> getAllData(boolean ascending) {
        return database.getAllItems(ascending);
    }
    public String getUser(String username, String password){
        return database.getUser(username, password);
    }

    public void removeItem(Item item) {
        database.removeItem(item);
    }

    public void writeOrder(String user, int size){
        database.writeOrder(user, size);
    }
    public ArrayList<Order> getOrders(){
        return database.getAllOrders();
    }

    public String checkItem(String title){
        return database.checkItem(title);
    }

    public void updateRating(String title, float rating){
        database.updateItemRating(title, rating);
    }

    public void updateItem(String item, int number){
        database.updateItemQuantity(item, number);
    }


    public ArrayList<Item> getAllData(String title, int which) {
        return database.getAllItems(title, which);
    }
}

