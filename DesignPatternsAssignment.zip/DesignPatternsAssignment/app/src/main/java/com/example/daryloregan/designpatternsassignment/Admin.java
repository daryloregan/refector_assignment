package com.example.daryloregan.designpatternsassignment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.PersistableBundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import controller.Controller;
import model.Item;

public class Admin extends AppCompatActivity {

    private final int ADD_ITEM_CODE = 1;
    String title;
    ListView list;
    AdminListAdapter adapter ;
    ArrayList<Item> data;
    boolean ascending = true;
    Controller controller ;
    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_admin);


        if(bundle!=null){
            data = (ArrayList<Item>) bundle.getSerializable("Data");
            adapter.notifyDataSetChanged();
        }

        controller = new Controller(this);
        list = (ListView) findViewById(R.id.admin_list);
        data = controller.getAllData(ascending);
        adapter = new AdminListAdapter(this, data);
        list.setAdapter(adapter);

    }

    @Override
    public void onResume(){
        super.onResume();
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.admin_menu, menu);
        return true;
    }


    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putSerializable("Data", data);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.admin_add){
            Bundle bundle = new Bundle();
            Intent intent = new Intent(Admin.this, AddItem.class);
            intent.putExtras(bundle);
            startActivity(intent);
            finish();
            return true;
        }
        else if(item.getItemId() == R.id.admin_sor){

            ascending = !(ascending);
            data.clear();
            data.addAll(controller.getAllData(ascending));


            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Sorted", Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId() == R.id.admin_orders){
            startActivity(new Intent(Admin.this, Orders.class));
        }
        else if(item.getItemId() == R.id.search_admin){
            String[] opt = {"Category", "Manufacturer", "Title"};
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);


            builder.setItems(opt, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, final int i) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(Admin.this);
                    final EditText input = new EditText(Admin.this);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    alertDialog.setView(input);


                    alertDialog.setTitle("Search");
                    if (i == 0) {
                        alertDialog.setMessage("Enter Category");
                    } else if (i == 1) {
                        alertDialog.setMessage("Enter Manufacturer");
                    } else {
                        alertDialog.setMessage("Enter Title");
                    }

                    alertDialog.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    title = input.getText().toString();
                                    data.clear();
                                    data.addAll(controller.getAllData(title, i));
                                    adapter.notifyDataSetChanged();
                                }
                            });

                    alertDialog.setNegativeButton("Cancel",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    alertDialog.show();
                }
            });
            builder.show();
        }

        return false;
    }

}
