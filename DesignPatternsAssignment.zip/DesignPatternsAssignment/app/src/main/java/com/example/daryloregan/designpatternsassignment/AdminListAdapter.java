package com.example.daryloregan.designpatternsassignment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

import controller.Controller;
import model.Item;


public class AdminListAdapter extends BaseAdapter {

    Context context;
    Controller controller;
    List<Item> data;

    AdminListAdapter(Context context, List<Item> data){
        this.context = context;
        controller = new Controller(context);
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.list_item, null);

        TextView title = (TextView)v.findViewById(R.id.item_title);
        TextView manufacture = (TextView)v.findViewById(R.id.item_manufacture);
        TextView price = (TextView)v.findViewById(R.id.item_price);
        ImageView image = (ImageView)v.findViewById(R.id.list_image);
        TextView number = (TextView)v.findViewById(R.id.item_number);
        ImageButton imagebtn = (ImageButton) v.findViewById(R.id.delete_item);
        final RatingBar rating = (RatingBar) v.findViewById(R.id.item_rating);

        final Item item = data.get(i);
        rating.setRating(Float.parseFloat(String.valueOf(item.getRating())));
        title.setText(item.getTitle());
        manufacture.setText(item.getManufacture());
        price.setText(String.valueOf(item.getPrice()));
        number.setText("Quantity: "+String.valueOf(item.getNumber()));
        byte[] bitmapdata = item.getImage();

        Bitmap bitmap = BitmapFactory.decodeByteArray(bitmapdata, 0, bitmapdata.length);;
        image.setImageBitmap(bitmap);

        rating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                controller.updateRating(item.getTitle(), ratingBar.getRating());
            }
        });


        imagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.remove(item);
                controller.removeItem(item);
                notifyDataSetChanged();
            }
        });
        return v;
    }
}
