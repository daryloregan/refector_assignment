package com.example.daryloregan.designpatternsassignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import controller.Controller;
import model.Item;

public class Cart extends AppCompatActivity {

    ListView cartList;
    Button order;
    ArrayList<Item> data;
    UserListAdapter adapter;

    Controller controller;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_cart);

        cartList = (ListView) findViewById(R.id.cart_list);
        controller = new Controller(this);
        order = (Button) findViewById(R.id.btn_order);
        data = (ArrayList<Item>) getIntent().getSerializableExtra("cart");
        adapter = new UserListAdapter(this, data, data);
        cartList.setAdapter(adapter);

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = getIntent().getStringExtra("user");
                controller.writeOrder(user, data.size());
                Toast.makeText(Cart.this, "Order Placed", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
}