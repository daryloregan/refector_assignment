package com.example.daryloregan.designpatternsassignment;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import controller.Controller;
import model.Item;

public class User extends AppCompatActivity {

    ListView list;
    Button viewCart;
    String title;
    UserListAdapter adapter;
    Controller controller;
    ArrayList<Item> data;

    boolean ascending = true;


    ArrayList<Item> cart;

    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_user);

        list = (ListView)findViewById(R.id.user_list);
        viewCart = (Button)findViewById(R.id.btn_view_cart);
        controller = new Controller(this);
        data = controller.getAllData(true);
        cart = new ArrayList<>();
        adapter = new UserListAdapter(this, data, cart);
        list.setAdapter(adapter);

        viewCart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(User.this, Cart.class);
                intent.putExtra("cart", cart);
                intent.putExtra("user", getIntent().getStringExtra("user"));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.user_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.admin_sor){
            ascending = !(ascending);
            data.clear();
            data.addAll(controller.getAllData(ascending));


            adapter.notifyDataSetChanged();

            Toast.makeText(this, "Sorted", Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId() == R.id.search_admin) {

            String[] opt = {"Category", "Manufacturer", "Title"};
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);


            builder.setItems(opt, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, final int i) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(User.this);
                    final EditText input = new EditText(User.this);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    alertDialog.setView(input);


                    alertDialog.setTitle("Search");
                    if (i == 0) {
                        alertDialog.setMessage("Enter Category");

                    } else if (i == 1) {
                        alertDialog.setMessage("Enter Manufacturer");
                    } else {
                        alertDialog.setMessage("Enter Title");
                    }

                    alertDialog.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    title = input.getText().toString();
                                    data.clear();
                                    data.addAll(controller.getAllData(title, i));
                                    adapter.notifyDataSetChanged();
                                }
                            });

                    alertDialog.setNegativeButton("Cancel",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    alertDialog.show();
                }
            });
            builder.show();
        }
        return true;
    }
}
