package com.example.daryloregan.designpatternsassignment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import controller.Controller;

public class MainActivity extends AppCompatActivity {

    TextView alreadyRegistered, text;
    Button registerButton;
    EditText username;
    EditText password;
    EditText shippingAddress;
    EditText paymentMethod;
    Spinner spinner;

    Controller controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        alreadyRegistered = (TextView) findViewById(R.id.already_registered);
        text = (TextView) findViewById(R.id.text);
        username = (EditText) findViewById(R.id.login_username);
        password = (EditText) findViewById(R.id.login_password);
        shippingAddress = (EditText) findViewById(R.id.login_address);
        paymentMethod = (EditText) findViewById(R.id.login_payment_method);
        registerButton = (Button) findViewById(R.id.register_btn);
        spinner = (Spinner) findViewById(R.id.user_type);

        controller = new Controller(this);

        alreadyRegistered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (alreadyRegistered.getText().equals("Sign in")) {

                    shippingAddress.setVisibility(view.GONE);
                    paymentMethod.setVisibility(view.GONE);
                    text.setVisibility(view.GONE);
                    spinner.setVisibility(view.GONE);


                    alreadyRegistered.setText("Register");
                    registerButton.setText("Sign in");


                } else {

                    shippingAddress.setVisibility(view.VISIBLE);
                    paymentMethod.setVisibility(view.VISIBLE);
                    password.setVisibility(view.VISIBLE);
                    spinner.setVisibility(view.VISIBLE);
                    text.setVisibility(view.VISIBLE);

                    alreadyRegistered.setText("Sign in");
                    text.setText("Not registered?");
                    registerButton.setText("Register");
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(registerButton.getText().equals("Register")) {

                    controller.addUser(username.getText().toString(), password.getText().toString(),
                            shippingAddress.getText().toString(), paymentMethod.getText().toString(),
                            spinner.getSelectedItem().toString());

                    Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(MainActivity.this, Admin.class));

                } else if (registerButton.getText().equals("Sign in")) {


                    String result = controller.checkLogin(username.getText().toString(), password.getText().toString());

                    if(result == null){
                        Toast.makeText(MainActivity.this, "No User Found", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.equals("Admin")){

                        Toast.makeText(MainActivity.this, "Admin user", Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(MainActivity.this, Admin.class));
                    }
                    else if(result.equals("User")){

                        Toast.makeText(MainActivity.this, "Buyer user", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this, User.class);
                        intent.putExtra("user", controller.getUser(username.getText().toString(), password.getText().toString()));
                        startActivity(intent);
                    }
                }
            }
        });
    }
}
