package com.example.daryloregan.designpatternsassignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import controller.Controller;
import model.Order;

public class OrderAdapter extends BaseAdapter {

    Context context;
    Controller controller;
    List<Order> data;

    OrderAdapter(Context context, List<Order> data){
        this.context = context;
        controller = new Controller(context);
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.order_item, null);

        TextView user = (TextView)v.findViewById(R.id.order_user);
        TextView size = (TextView)v.findViewById(R.id.order_size);


        final Order order = data.get(i);

        user.setText("User: "+order.getUser());
        size.setText("Total Items: "+String.valueOf(order.getSize()));


        return v;
    }
}
