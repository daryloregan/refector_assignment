package com.example.daryloregan.designpatternsassignment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import controller.Controller;
import model.Item;

public class UserListAdapter extends BaseAdapter {

    Context context;
    Controller controller;
    List<Item> data;
    List<Item> cart;

    UserListAdapter(Context context, List<Item> data, List<Item> cart){
        this.context = context;
        controller = new Controller(context);
        this.data = data;
        this.cart = cart;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.list_item, null);

        TextView title = (TextView)v.findViewById(R.id.item_title);
        TextView manufacture = (TextView)v.findViewById(R.id.item_manufacture);
        TextView price = (TextView)v.findViewById(R.id.item_price);
        ImageView image = (ImageView)v.findViewById(R.id.list_image);
        ImageButton imagebtn = (ImageButton) v.findViewById(R.id.delete_item);
        RatingBar rating = (RatingBar)v.findViewById(R.id.item_rating);
        final Item item = data.get(i);

        title.setText(item.getTitle());
        manufacture.setText(item.getManufacture());
        price.setText(String.valueOf(item.getPrice()));
        byte[] bitmapdata = item.getImage();
        rating.setRating(item.getRating());

        Bitmap bitmap = BitmapFactory.decodeByteArray(bitmapdata, 0, bitmapdata.length);;
        image.setImageBitmap(bitmap);




        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(item.getNumber() > 0){
                    cart.add(item);
                    controller.updateItem(item.getTitle(), item.getNumber() -1);
                    Toast.makeText(context, "Item added to Cart", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(context, "Out of Stock", Toast.LENGTH_SHORT).show();
                }
            }
        });

        imagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.remove(item);
                notifyDataSetChanged();
            }
        });
        return v;
    }
}


