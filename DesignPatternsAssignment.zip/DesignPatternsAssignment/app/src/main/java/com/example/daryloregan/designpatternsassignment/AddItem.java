package com.example.daryloregan.designpatternsassignment;


import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.IOException;

import controller.Controller;
import model.Item;

public class AddItem extends AppCompatActivity {


    EditText title;
    EditText category;
    EditText manufacture;
    EditText price;
    ImageView image;
    EditText quantity;
    Bitmap bitmap;
    String realPath;
    Controller controller;
    Button add;
    private final int PICK_IMAGE_REQUEST = 1;

    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_add_item);

        checkForPermissions();

        controller = new Controller(this);
        title = (EditText) findViewById(R.id.add_title);
        category = (EditText) findViewById(R.id.add_category);
        manufacture = (EditText) findViewById(R.id.add_manufacturer);
        price = (EditText) findViewById(R.id.add_price);
        image = (ImageView) findViewById(R.id.select_image);
        add = (Button) findViewById(R.id.add_item);
        quantity = (EditText)findViewById(R.id.add_quantity);


        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 1. on Upload click call ACTION_GET_CONTENT intent
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                // 2. pick image only
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileInputStream fstream = new FileInputStream(realPath);

                    byte[] byteArray = new byte[fstream.available()];
                    fstream.read(byteArray);
                    fstream.close();

                    Item item = new Item(title.getText().toString(), category.getText().toString(), manufacture.getText().toString(),
                            Double.parseDouble(price.getText().toString()), byteArray,
                            Integer.parseInt(quantity.getText().toString()),2.5f);


                    if(controller.checkItem(title.getText().toString()) != null){
                        int quant= Integer.parseInt(controller.checkItem((title.getText().toString())));
                        controller.updateItem(title.getText().toString(),
                                quant+Integer.parseInt(quantity.getText().toString()));
                    }else{
                        controller.addItem(item);
                    }


                    startActivity(new Intent(AddItem.this, Admin.class));
                    finish();


                } catch (Exception e) {
                    Toast.makeText(AddItem.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE_REQUEST){

            if (data != null) {
                try {

                    bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                } catch (IOException e) {
                    e.printStackTrace();
                }


                // SDK < API11
                if (Build.VERSION.SDK_INT < 11)
                    realPath = RealPathUtil.getRealPathFromURI_BelowAPI11(this, data.getData());

                    // SDK >= 11 && SDK < 19
                else if (Build.VERSION.SDK_INT < 19)
                    realPath = RealPathUtil.getRealPathFromURI_API11to18(this, data.getData());

                    // SDK > 19 (Android 4.4)
                else
                    realPath = RealPathUtil.getRealPathFromURI_API19(this, data.getData());

            }
            image.setImageBitmap(bitmap);

        }
    }

    private void checkForPermissions() {
        if (ContextCompat.checkSelfPermission(AddItem.this, Manifest.permission.READ_EXTERNAL_STORAGE) != 0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                ActivityCompat.requestPermissions(
                        AddItem.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 1000);
//                ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.CAMERA},1000);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            if (ContextCompat.checkSelfPermission(AddItem.this, permissions[0]) == 0) {
                Toast.makeText(AddItem.this, "Permission Granted", Toast.LENGTH_LONG).show();
            }
        }
    }

}
