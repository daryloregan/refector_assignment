package com.example.daryloregan.designpatternsassignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import controller.Controller;
import model.Order;

public class Orders extends AppCompatActivity {

    OrderAdapter adapter;
    ArrayList<Order> data;
    Controller controller;

    ListView list;

    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_orders);

        controller = new Controller(this);
        data = controller.getOrders();
        adapter = new OrderAdapter(this, data);
        list = (ListView)findViewById(R.id.orders);
        list.setAdapter(adapter);
    }
}
