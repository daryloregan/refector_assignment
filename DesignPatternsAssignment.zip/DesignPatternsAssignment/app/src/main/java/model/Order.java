package model;

public class Order {
    String user;
    int size;

    Order(String user, int size){
        this.user = user;
        this.size = size;
    }

    public String getUser(){
        return user;
    }
    public int getSize(){
        return size;
    }
}
