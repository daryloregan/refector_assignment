package model;

import android.support.annotation.NonNull;

import java.io.Serializable;

public class Item implements Serializable, Comparable<Item>{
    private String title;
    private String category;
    private String manufacture;
    private double price;
    private byte[] image;
    private boolean ascending = true;
    private int number;
    private float rating;


    public Item(String title, String category, String manufacture, double price, byte[] image, int number, float rating) {
        this.title = title;
        this.category = category;
        this.manufacture = manufacture;
        this.price = price;
        this.image = image;
        this.number = number;
        this.rating = rating;
    }

    public float getRating(){
        return  rating;
    }
    public void setRating(float rating){
        this.rating = rating;
    }


    public int getNumber(){
        return this.number;
    }

    public String getTitle() {
        return title;
    }

    public void setBitmap(byte[] image){
        this.image = image;
    }
    public byte[] getImage(){
        return this.image ;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getManufacture() {
        return manufacture;
    }

    public void setManufacture(String manufacture) {
        this.manufacture = manufacture;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int compareTo(@NonNull Item item) {

        this.ascending = !(ascending);
        if(ascending) {
            return this.getTitle().compareTo(item.getTitle());
        }
        else
            return item.getTitle().compareTo(this.getTitle());
    }

    public void setQuantity(int quantity) {
        this.number = quantity;
    }
}
