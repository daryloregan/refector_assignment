package model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private String TABLE_USERS = "users";
    private String COLUMN_USERNAME = "username";
    private String COLUMN_PASSWORD = "password";
    private String COLUMN_ADDRESS = "address";
    private String COLUMN_PAYMENT_METHOD = "payment_method";
    private String COLUMN_TYPE = "type";


    private String TABLE_ITEM = "item";
    private String COLUMN_TITLE = "title";
    private String COLUMN_CATEGORY = "category";
    private String COLUMN_MANUFACTURE = "manufacture";
    private String COLUMN_PRICE = "price";
    private String COLUMN_IMAGE = "image";
    private String COLUMN_NUMBER = "number";
    private String COLUMN_RATING = "rating";

    private String TABLE_ORDERS = "orders";
    private String COLUMN_SIZE = "size";


    public Database(Context context) {
        super(context, "Test.db", null, 6);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table " + TABLE_USERS +
                        "(" + COLUMN_USERNAME +
                        " text ," + COLUMN_PASSWORD + " text," + COLUMN_ADDRESS + " text," + COLUMN_PAYMENT_METHOD + "" +
                        " text," + COLUMN_TYPE + " text)");


        db.execSQL(
                "create table " + TABLE_ITEM +
                        "(" + COLUMN_TITLE +
                        " text ," + COLUMN_CATEGORY + " text," + COLUMN_MANUFACTURE + " text," + COLUMN_PRICE + "" +
                        " text," + COLUMN_NUMBER + " text," + COLUMN_RATING + " text," + COLUMN_IMAGE + " blob)");

        db.execSQL(
                "create table " + TABLE_ORDERS +
                        "(" + COLUMN_USERNAME +
                        " text ," + COLUMN_SIZE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEM);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        onCreate(db);
    }

    public void addUser(String username, String password, String address, String payment, String type) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        contentValues.put(COLUMN_ADDRESS, address);
        contentValues.put(COLUMN_PAYMENT_METHOD, password);
        contentValues.put(COLUMN_TYPE, type);
        db.insert(TABLE_USERS, null, contentValues);
    }

    public String checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor resultSet = db.rawQuery("Select * from " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "= '" + username + "' AND " +
                "" + COLUMN_PASSWORD + "= '" + password + "'", null);

        if (resultSet.isAfterLast())
            return null;
        resultSet.moveToFirst();

        return resultSet.getString(resultSet.getColumnIndex(COLUMN_TYPE));


    }

    public String getUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor resultSet = db.rawQuery("Select * from " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "= '" + username + "' AND " +
                "" + COLUMN_PASSWORD + "= '" + password + "'", null);

        if (resultSet.isAfterLast())
            return null;
        resultSet.moveToFirst();

        return resultSet.getString(resultSet.getColumnIndex(COLUMN_USERNAME));

    }

    public void addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_TITLE, item.getTitle());
        contentValues.put(COLUMN_CATEGORY, item.getCategory());
        contentValues.put(COLUMN_MANUFACTURE, item.getManufacture());
        contentValues.put(COLUMN_PRICE, item.getPrice());
        contentValues.put(COLUMN_IMAGE, item.getImage());
        contentValues.put(COLUMN_NUMBER, item.getNumber());
        contentValues.put(COLUMN_RATING, item.getRating());
        db.insert(TABLE_ITEM, null, contentValues);


    }

    public ArrayList<Item> getAllItems(boolean ascending) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor resultSet = null;

        if (ascending)
            resultSet = db.rawQuery("SELECT * FROM " + TABLE_ITEM + " ORDER BY " + COLUMN_PRICE + " ASC", null);
        else
            resultSet = db.rawQuery("SELECT * FROM " + TABLE_ITEM + " ORDER BY " + COLUMN_PRICE + " DESC", null);


        ArrayList<Item> list = new ArrayList<>();

        while (resultSet.moveToNext()) {
            String title = resultSet.getString(resultSet.getColumnIndex(COLUMN_TITLE));
            String category = resultSet.getString(resultSet.getColumnIndex(COLUMN_CATEGORY));
            String manufacture = resultSet.getString(resultSet.getColumnIndex(COLUMN_MANUFACTURE));
            String price = resultSet.getString(resultSet.getColumnIndex(COLUMN_PRICE));
            byte[] image = resultSet.getBlob(resultSet.getColumnIndex(COLUMN_IMAGE));
            String quantity = resultSet.getString(resultSet.getColumnIndex(COLUMN_NUMBER));
            float rating = Float.parseFloat(resultSet.getString(resultSet.getColumnIndex(COLUMN_RATING)));
            Item item = new Item(title, category, manufacture, Double.parseDouble(price), image,
                    Integer.parseInt(quantity), rating);

            list.add(item);
        }
        return list;
    }

    public ArrayList<Item> getAllItems(String title1, int which) {
        SQLiteDatabase db = this.getReadableDatabase();

        String column = "";

        if (which == 0)
            column = COLUMN_CATEGORY;
        else if (which == 1)
            column = COLUMN_MANUFACTURE;
        else if (which == 2)
            column = COLUMN_TITLE;

        Cursor resultSet = null;

        resultSet = db.rawQuery("SELECT * FROM " + TABLE_ITEM + " WHERE " + column + "='" + title1 + "'", null);


        ArrayList<Item> list = new ArrayList<>();

        while (resultSet.moveToNext()) {
            String title = resultSet.getString(resultSet.getColumnIndex(COLUMN_TITLE));
            String category = resultSet.getString(resultSet.getColumnIndex(COLUMN_CATEGORY));
            String manufacture = resultSet.getString(resultSet.getColumnIndex(COLUMN_MANUFACTURE));
            String price = resultSet.getString(resultSet.getColumnIndex(COLUMN_PRICE));
            byte[] image = resultSet.getBlob(resultSet.getColumnIndex(COLUMN_IMAGE));
            String quantity = resultSet.getString(resultSet.getColumnIndex(COLUMN_NUMBER));

            float rating = Float.parseFloat(resultSet.getString(resultSet.getColumnIndex(COLUMN_RATING)));
            Item item = new Item(title, category, manufacture, Double.parseDouble(price), image,
                    Integer.parseInt(quantity), rating);
            list.add(item);
        }
        return list;
    }


    public void removeItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_ITEM + " WHERE " + COLUMN_TITLE + "='" + item.getTitle() + "'");
    }

    public void writeOrder(String user, int size) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, user);
        contentValues.put(COLUMN_SIZE, String.valueOf(size));

        db.insert(TABLE_ORDERS, null, contentValues);
    }

    public ArrayList<Order> getAllOrders() {
        SQLiteDatabase db = this.getReadableDatabase();


        Cursor resultSet = db.rawQuery("SELECT * FROM " + TABLE_ORDERS, null);


        ArrayList<Order> list = new ArrayList<>();

        while (resultSet.moveToNext()) {
            String user = resultSet.getString(resultSet.getColumnIndex(COLUMN_USERNAME));
            String size = resultSet.getString(resultSet.getColumnIndex(COLUMN_SIZE));

            list.add(new Order(user, Integer.parseInt(size)));
        }

        return list;
    }

    public void updateItemQuantity(String item, int number) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("UPDATE " + TABLE_ITEM + " SET " + COLUMN_NUMBER + " ='" + number + "' WHERE " + COLUMN_TITLE
                + " ='" + item + "'");
    }

    public void updateItemRating(String item, double rating) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("UPDATE " + TABLE_ITEM + " SET " + COLUMN_RATING + " ='" + rating + "' WHERE " + COLUMN_TITLE
                + " ='" + item + "'");
    }

    public String checkItem(String title) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor resultSet = db.rawQuery("Select * from " + TABLE_ITEM + " WHERE " + COLUMN_TITLE + "= '" + title + "'", null);

        if (resultSet.isAfterLast())
            return null;

        resultSet.moveToFirst();

        return resultSet.getString(resultSet.getColumnIndex(COLUMN_NUMBER));


    }
}

